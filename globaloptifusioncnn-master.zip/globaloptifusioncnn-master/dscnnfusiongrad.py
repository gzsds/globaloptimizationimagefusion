import cv2
import numpy as np
import matplotlib.pyplot as plt


import tensorflow as tf
import tensorflow.keras as keras
import ssimpython
import ssimtensor
from sklearn import metrics as mr
import random


# 

def grad_loss(y_true,y_pred,nir,vis):
	nir=tf.cast(nir,tf.float32)
	vis=tf.cast(vis,tf.float32)
	mse = tf.reduce_mean(tf.square(y_pred - y_true), axis=-1)
	

	#w  = [1 4 6 4 1] / 16;
	kernelx = tf.constant([
		[
			[-1.0],  [0.0], [1.0],
			[-2.0],  [0.0], [2.0],
			[-1.0],  [0.0], [1.0]
		]
	],shape=[3,3,1,1])
	kernely = tf.constant([
		[
			[-1.0], [-2.0], [-1.0],
			[0.0],  [0.0], [0.0],
			[1.0],  [2.0], [1.0]
		]
	],shape=[3,3,1,1])

	# 清晰度正则化
	# kernelx = kernelx/2.0
	# kernely = kernely/2.0
	cnir = tf.nn.conv2d(nir, kernelx, strides=[1, 1, 1, 1], padding='SAME')
	rnir = tf.nn.conv2d(nir, kernely, strides=[1, 1, 1, 1], padding='SAME')
	hfnir = tf.square(cnir)+tf.square(rnir)
	# hfnir = keras.sqrt(hfnir)
	
	cvis = tf.nn.conv2d(vis, kernelx, strides=[1, 1, 1, 1], padding='SAME')
	rvis = tf.nn.conv2d(vis, kernely, strides=[1, 1, 1, 1], padding='SAME')
	hfvis = tf.square(cvis)+tf.square(rvis)
	# hfvis = keras.sqrt(hfvis)
	
	cpred = tf.nn.conv2d(y_pred, kernelx, strides=[1, 1, 1, 1], padding='SAME')
	rpred = tf.nn.conv2d(y_pred, kernely, strides=[1, 1, 1, 1], padding='SAME')
	hfy_pred = tf.square(cpred)+tf.square(rpred)
	# hfy_pred = keras.sqrt(hfy_pred)

	grad = tf.reduce_mean(tf.abs(hfy_pred - tf.maximum(hfvis,hfnir)), axis=-1)
	return mse+130.0*grad  


	# return grad  
def regugrad_loss(nis, vis):
	def grad(y_true,y_pred):
		return grad_loss(y_true,y_pred,nis,vis)
	return grad  



fn = 4;
strfn = str(fn).zfill(2);

nirfile = "data/redata/b"+strfn+"_2.tif"
visfile = "data/redata/b"+strfn+"_1.tif"
nsctfile = "data/nsct/iv_"+strfn+"_nsct.tif"

Imgnir = cv2.imread(nirfile,cv2.IMREAD_GRAYSCALE)
Imgvis = cv2.imread(visfile,cv2.IMREAD_GRAYSCALE)
Imgnsct = cv2.imread(nsctfile,cv2.IMREAD_GRAYSCALE)

ssim = ssimpython.compute_ssim(Imgnir,Imgvis);
print( ssim)
print(Imgnir.shape)

Imgnir = Imgnir.reshape(1,Imgnir.shape[0],Imgnir.shape[1],1)
Imgvis = Imgvis.reshape(1,Imgvis.shape[0],Imgvis.shape[1],1)
Imgnsct = Imgnsct.reshape(1,Imgnsct.shape[0],Imgnsct.shape[1],1)


nirinput = keras.Input(shape=(None,None,1)) #nirinput = Input(shape=(256,256,1))
visinput = keras.Input(shape=(None,None,1))
maininput = keras.Input(shape=(None,None,1))

bfn = 128
sfn = 64

bon1 = keras.layers.Conv2D(bfn,(3,3),padding='same',activation='relu')(maininput)
# bon1 = BatchNormalization(axis=3)(bon1)
nir1 = keras.layers.Conv2D(sfn,(3,3),padding='same',activation='relu')(nirinput)
vis1 = keras.layers.Conv2D(sfn,(3,3),padding='same',activation='relu')(visinput)
con1 = keras.layers.concatenate([bon1,nir1,vis1, nirinput, visinput],axis=3)

bon2 = keras.layers.Conv2D(bfn,(3,3),padding='same',activation='relu')(con1)
nir2 = keras.layers.Conv2D(sfn,(3,3),padding='same',activation='relu')(nir1)
vis2 = keras.layers.Conv2D(sfn,(3,3),padding='same',activation='relu')(vis1)
con2 = keras.layers.concatenate([bon2,nir2,vis2, nirinput, visinput],axis=3)

bon3 = keras.layers.Conv2D(bfn,(3,3),padding='same',activation='relu')(con2)
nir3 = keras.layers.Conv2D(sfn,(3,3),padding='same',activation='relu')(nir2)
vis3 = keras.layers.Conv2D(sfn,(3,3),padding='same',activation='relu')(vis2)
con3 = keras.layers.concatenate([bon3,nir3,vis3, nirinput, visinput],axis=3)

bon4 = keras.layers.Conv2D(bfn,(3,3),padding='same',activation='relu')(con3)
nir4 = keras.layers.Conv2D(sfn,(3,3),padding='same',activation='relu')(nir3)
vis4 = keras.layers.Conv2D(sfn,(3,3),padding='same',activation='relu')(vis3)
con4 = keras.layers.concatenate([bon4,nir4,vis4, nirinput, visinput],axis=3)

output = keras.layers.Conv2D(bfn,(3,3),padding='same',activation='relu')(con4)
# output = Conv2D(32,(3,3),padding='same',activation='relu')(output)
output = keras.layers.Conv2D(1,(1,1),padding='same')(output)

model = keras.Model(inputs = [nirinput,visinput,maininput], outputs = output)

model.summary()
mode_loss = regugrad_loss(Imgnir,Imgvis)

for i in range(1,2):

	model.compile(optimizer = keras.optimizers.Adam(lr = 5e-4,decay=1e-6), loss = mode_loss, metrics = ['accuracy'])

	model.load_weights('init_weights.h5')

	# checkpoint  
	filepath = "best_weights.h5"
	#checkpoint = ModelCheckpoint(filepath, monitor='val_acc', verbose=0, save_best_only=True, mode='max', period=1)
	checkpoint = tf.keras.callbacks.ModelCheckpoint(filepath, monitor='loss', save_weights_only=True, verbose=0, save_best_only=True, mode='min', period=1)
	callbacks_list = [checkpoint]


	model.fit([Imgnir,Imgvis,Imgnsct], Imgnsct,  epochs=600, batch_size=1, callbacks = callbacks_list)

	model = keras.Model(inputs = [nirinput,visinput,maininput], outputs = output)
	model.load_weights('best_weights.h5')
	preoutput = model.predict([Imgnir,Imgvis,Imgnsct])

	print(preoutput[0].shape)
	print(preoutput[0])
	# plt.imshow(preoutput[0].reshape([240,320]))
	cv2.imwrite("data/our/"+strfn+"_"+str(i)+"our.png",preoutput[0])
	# cv2.imshow("dd",preoutput[0])
	# cv2.waitKey (0)  
	# cv2.destroyWindow("dd") 

