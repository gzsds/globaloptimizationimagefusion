import cv2
import numpy as np
import matplotlib.pyplot as plt


import tensorflow as tf
from keras.models import *
from keras.layers import *
from keras.optimizers import *
from keras import backend as keras
import ssimpython
import ssimtensor
from sklearn import metrics as mr




# def ssim_loss(y_true,y_pred):
# 	mse =keras.sqrt(keras.square(y_true-y_pred))
# 	mse = keras.mean(mse,axis=-1)
# 	print(mse);

#     return keras.mean((y_pred-y_true),axis = -1)

def getQ(Qg,Qa):
	# return tf.multiply(Qg,Qa)
	return Qg*Qa
def getQa(A,Ta,Ka,Oa):
	return Ta/(1+keras.exp(Ka*(A-Oa)))
def getQg(G,Tg,Kg,Og):
	return Tg/(1+keras.exp(Kg*(G-Og))) 
def get2A(alm1,alm2):
	# return 1-keras.abs( keras.square(alm1-alm2)/3.1415926 )
	# return keras.abs( keras.square(alm1-alm2)/3.1415926 )
	return 1-keras.abs( ((alm1-alm2)*2)/3.1415926 )
def get2G(glm1,glm2):
	return keras.minimum(glm1,glm2)/(keras.maximum(glm1,glm2)+0.0000001)
def get_g_a(im):
	kernelx = tf.constant([
		[
			[-1.0],  [0.0], [1.0],
			[-2.0],  [0.0], [2.0],
			[-1.0],  [0.0], [1.0]
		]
	],shape=[3,3,1,1])
	kernely = tf.constant([
		[
			[-1.0], [-2.0], [-1.0],
			[0.0],  [0.0], [0.0],
			[1.0],  [2.0], [1.0]
		]
	],shape=[3,3,1,1])
	convresx = tf.nn.conv2d(im, kernelx, strides=[1, 1, 1, 1], padding='SAME') #这种获得了一定的效果
	convresy = tf.nn.conv2d(im, kernely, strides=[1, 1, 1, 1], padding='SAME')
	# grad = keras.sqrt(keras.square(convresx)+keras.square(convresy) )  #可能有负数
	grad = keras.square(convresx)+keras.square(convresy) 
	at = tf.atan2(convresx,convresy+0.0000001,name='at')

	return grad,at

def grad_loss(y_true,y_pred,nir,vis):
	nir=tf.cast(nir,tf.float32)
	vis=tf.cast(vis,tf.float32)
	# y_pred=tf.cast(y_pred,tf.float32)
	
	mse = keras.mean(keras.square(y_pred - y_true), axis=-1)
	A = vis
	B = nir
	F = y_pred
	gA,aA = get_g_a(A)
	gB,aB = get_g_a(B)
	gF,aF = get_g_a(F)
	GAF = get2G(gA,gF)
	GBF = get2G(gB,gF)
	AAF = get2A(aA,aF)
	ABF = get2A(aB,aF)
	QgAF = getQg(GAF,0.9994,-15.0,0.5)
	QgBF = getQg(GBF,0.9994,-15.0,0.5)
	QaAF = getQa(AAF,0.9879,-22.0,0.8)
	QaBF = getQa(ABF,0.9879,-22.0,0.8)
	QAF = getQ(QgAF,QaAF)
	QBF = getQ(QgBF,QaBF)
	# QAF = GAF
	# QBF = GBF
	a = keras.sum(tf.multiply(QAF,gA)+tf.multiply(QBF,gB),axis=-1) #sum(sum(QAF.*gA+QBF.*gB));
	b = keras.sum((gA+gB),axis=-1) #sum(sum(gA+gB));
	# a = keras.sum(tf.multiply(QAF,gA)+tf.multiply(QBF,gB)) #sum(sum(QAF.*gA+QBF.*gB));
	# b = tf.reduce_sum((gA+gB)) #sum(sum(gA+gB));
	print("aa:")
	
	result=a/(b+0.0000001)
	# mse = keras.sum(mse,axis=0)
	# mse = keras.sum(mse,axis=0)
	# mse = keras.sum(mse,axis=0)
	# result = keras.sum(result,axis=0)
	# result = keras.sum(result,axis=0)
	# result = keras.sum(result,axis=0)
	# print(mse)
	result = result
	return mse-1800.001*result
	# return mse-800.001*result

	# return mse-500.5*result
def regugrad_loss(nis, vis):
	def grad(y_true,y_pred):
		return grad_loss(y_true,y_pred,nis,vis)
	return grad  


nirfile = "1nir.tif"
visfile = "1vis.tif"
# nsctfile = "b04_1[3-RP].tif"
nsctfile = "b04_1[17-JSR-OUR].tif"

# nirfile = "a01_1.tif"
# visfile = "a01_2.tif"
# # nsctfile = "b04_1[3-RP].tif"
# nsctfile = "a01_1[8-NSCT].tif"



Imgnir = cv2.imread(nirfile,cv2.IMREAD_GRAYSCALE)
Imgvis = cv2.imread(visfile,cv2.IMREAD_GRAYSCALE)
Imgnsct = cv2.imread(nsctfile,cv2.IMREAD_GRAYSCALE)

ssim = ssimpython.compute_ssim(Imgnir,Imgvis)
print( ssim)
print(Imgnir.shape)

Imgnir = Imgnir.reshape(1,Imgnir.shape[0],Imgnir.shape[1],1)
Imgvis = Imgvis.reshape(1,Imgvis.shape[0],Imgvis.shape[1],1)
Imgnsct = Imgnsct.reshape(1,Imgnsct.shape[0],Imgnsct.shape[1],1)

# Imgnir=tf.cast(Imgnir,tf.float32)
# Imgvis=tf.cast(Imgvis,tf.float32)
# Imgnsct=tf.cast(Imgnsct,tf.float32)
# Imgnir = Imgnir / 255
# Imgvis /= 255
# Imgnsct /=255
# result = grad_loss(Imgnsct,Imgnsct,Imgnir,Imgvis)
# result = keras.sum(result,axis=0)
# result = keras.sum(result,axis=0)
# result = keras.sum(result,axis=0)

# init = tf.global_variables_initializer()
# with tf.Session() as sess:
# 	sess.run(init)
# 	#eval方法只有当session开启的时候才好用
# 	#Tensor.eval 方法返回一个python的numpy对象，和原来的张量有着相同的值
# 	print(result.eval())
# print()
# exit()

# cv2.imshow("dd",Imgnsct)
# cv2.waitKey (0)  
# cv2.destroyWindow() 

nirinput = Input(shape=(None,None,1)) #nirinput = Input(shape=(256,256,1))
visinput = Input(shape=(None,None,1))
maininput = Input(shape=(None,None,1))

bon1 = Conv2D(128,(3,3),padding='same',activation='relu')(maininput)
nir1 = Conv2D(64,(3,3),padding='same',activation='relu')(nirinput)
vis1 = Conv2D(64,(3,3),padding='same',activation='relu')(visinput)
con1 = concatenate([bon1,nir1,vis1],axis=3)

bon2 = Conv2D(128,(3,3),padding='same',activation='relu')(con1)
nir2 = Conv2D(64,(3,3),padding='same',activation='relu')(nirinput)
vis2 = Conv2D(64,(3,3),padding='same',activation='relu')(visinput)
con2 = concatenate([bon2,nir2,vis2],axis=3)

bon3 = Conv2D(128,(3,3),padding='same',activation='relu')(con2)
nir3 = Conv2D(64,(3,3),padding='same',activation='relu')(nirinput)
vis3 = Conv2D(64,(3,3),padding='same',activation='relu')(visinput)
con3 = concatenate([bon3,nir3,vis3],axis=3)

output = Conv2D(128,(3,3),padding='same',activation='relu')(con3)
output = Conv2D(1,(1,1),padding='same')(output)

model = Model(input = [nirinput,visinput,maininput], output = output)

model.summary()
mode_loss = regugrad_loss(Imgnir,Imgvis)
# model.compile(optimizer = Adam(lr = 1e-4), loss = 'mean_squared_error', metrics = ['accuracy'])
model.compile(optimizer = Adam(lr = 1e-4), loss = mode_loss, metrics = ['accuracy'])



# model.fit({'nirinput': Imgnir, 'visinput': Imgvis,'maininput': Imgnsct}, {'output': Imgnsct},
#           epochs=50, batch_size=1)

model.fit([Imgnir,Imgvis,Imgnsct], Imgnsct,  epochs=800, batch_size=1)

preoutput = model.predict([Imgnir,Imgvis,Imgnsct])

print(preoutput[0].shape)
print(preoutput[0])
# plt.imshow(preoutput[0].reshape([240,320]))
cv2.imwrite("jsr.png",preoutput[0])
# cv2.imshow("dd",preoutput[0])
# cv2.waitKey (0)  
# cv2.destroyWindow("dd") 

