path(path,'fusion_evaluation/')
addpath('nsct_toolbox');

ParaRule.Low_Coeffs_Rule='ave'; 
ParaRule.High_Coeffs_Rule='max';


nir=imread('data\redata\b01_1.tif');
vis=imread('data\redata\b01_2.tif');



nir = double(nir);
vis = double(vis);

nsctresult = NSCT_fusion(nir,vis,ParaRule);
nsctresult = uint8(nsctresult);
% iv_"+fn+"_nsct.tif"
imwrite(nsctresult,'data/nsct/iv_01_nsct.tif');



% EvalResult_NSCT = Evaluation(nir,vis,nsctresult,256);