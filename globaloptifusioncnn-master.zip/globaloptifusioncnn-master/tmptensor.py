import tensorflow as tf
from keras import backend as keras
constant = tf.constant([1, 2, 3])
constant2 = tf.constant([3, 2, 1])
#进行点乘，对应位置的元素相乘
# tensor = constant *constant
# tensor=tf.multiply(constant,constant)

tensor = 1+constant
tensor = keras.minimum(constant,constant2)

init = tf.global_variables_initializer()
with tf.Session() as sess:
    sess.run(init)
    #eval方法只有当session开启的时候才好用
    #Tensor.eval 方法返回一个python的numpy对象，和原来的张量有着相同的值
    print(tensor.eval())